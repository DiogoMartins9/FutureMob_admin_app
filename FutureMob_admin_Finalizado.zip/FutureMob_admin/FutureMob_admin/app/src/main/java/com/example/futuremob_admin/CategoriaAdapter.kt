package com.example.futuremob_admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.Categoria

class CategoriaAdapter(
    private val categorias: List<Categoria>,
    private val onEditar: (Categoria) -> Unit,
    private val onExcluir: (Categoria) -> Unit
) : RecyclerView.Adapter<CategoriaAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtId: TextView = itemView.findViewById(R.id.txtIdCategoria)
        val txtNome: TextView = itemView.findViewById(R.id.txtNomeCategoria)
        val txtDescricao: TextView = itemView.findViewById(R.id.txtDescricaoCategoria)
        val txtIcone: TextView = itemView.findViewById(R.id.txtIconeCategoria)
        val btnEditar: ImageButton = itemView.findViewById(R.id.btnEditarCategoria)
        val btnExcluir: ImageButton = itemView.findViewById(R.id.btnExcluirCategoria)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_categoria, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = categorias.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val categoria = categorias[position]
        holder.txtId.text = categoria.id.toString()
        holder.txtNome.text = categoria.nome
        holder.txtDescricao.text = categoria.descricao
        holder.txtIcone.text = categoria.caminhoIcone ?: ""

        holder.btnEditar.setOnClickListener { onEditar(categoria) }
        holder.btnExcluir.setOnClickListener { onExcluir(categoria) }
    }
}