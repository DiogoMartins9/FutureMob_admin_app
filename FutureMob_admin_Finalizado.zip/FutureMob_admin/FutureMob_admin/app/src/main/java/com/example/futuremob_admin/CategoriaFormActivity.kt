package com.example.futuremob_admin

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.futuremob_admin.models.Categoria
import com.example.futuremob_admin.models.CategoriaRequest
import com.example.futuremob_admin.service.CategoriaService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class CategoriaFormActivity : AppCompatActivity() {

    private var categoriaEdicao: Categoria? = null

    companion object {
        private const val EXTRA_CATEGORIA = "extra_categoria"

        fun startAdicionar(context: Context) {
            val intent = Intent(context, CategoriaFormActivity::class.java)
            context.startActivity(intent)
        }

        fun startEditar(context: Context, categoria: Categoria) {
            val intent = Intent(context, CategoriaFormActivity::class.java)
            intent.putExtra(EXTRA_CATEGORIA, categoria)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categoria_form)

        val txtTituloForm = findViewById<TextView>(R.id.txtTituloFormulario)
        val txtDataHora = findViewById<TextView>(R.id.txtDataHoraForm)
        val edtNome = findViewById<EditText>(R.id.edtNomeCategoria)
        val edtCaminhoIcone = findViewById<EditText>(R.id.edtCaminhoIconeCategoria)
        val edtDescricao = findViewById<EditText>(R.id.edtDescricaoCategoria)
        val btnCancelar = findViewById<Button>(R.id.btnCancelarCategoria)
        val btnConfirmar = findViewById<Button>(R.id.btnConfirmarCategoria)

        val sdf = SimpleDateFormat("dd 'de' MMMM 'de' yyyy - HH:mm", Locale("pt", "BR"))
        txtDataHora.text = sdf.format(Date())

        // Verifica se é edição ou criação
        categoriaEdicao = intent.getSerializableExtra(EXTRA_CATEGORIA) as? Categoria

        if (categoriaEdicao != null) {
            txtTituloForm.text = "Editar Categoria"
            edtNome.setText(categoriaEdicao!!.nome)
            edtCaminhoIcone.setText(categoriaEdicao!!.caminhoIcone ?: "")
            edtDescricao.setText(categoriaEdicao!!.descricao)
        } else {
            txtTituloForm.text = "+ Adicionar Categoria"
        }

        btnCancelar.setOnClickListener { finish() }

        btnConfirmar.setOnClickListener {
            val nome = edtNome.text.toString().trim()
            val caminhoIcone = edtCaminhoIcone.text.toString().trim().ifBlank { null }
            val descricao = edtDescricao.text.toString().trim()

            if (nome.isEmpty() || descricao.isEmpty()) {
                Toast.makeText(this, "Preencha nome e descrição.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val request = CategoriaRequest(
                nome = nome,
                descricao = descricao,
                caminhoIcone = caminhoIcone
            )

            val service = ClientRetrofit.instance.create(CategoriaService::class.java)

            if (categoriaEdicao == null) {
                // Criar
                service.criar(request).enqueue(object : Callback<Categoria> {
                    override fun onResponse(call: Call<Categoria>, response: Response<Categoria>) {
                        if (response.isSuccessful) {
                            Toast.makeText(this@CategoriaFormActivity, "Categoria criada com sucesso!", Toast.LENGTH_SHORT).show()
                            finish()
                        } else {
                            Toast.makeText(this@CategoriaFormActivity, "Erro ao criar categoria.", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<Categoria>, t: Throwable) {
                        Toast.makeText(this@CategoriaFormActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
                    }
                })
            } else {
                // Atualizar
                val id = categoriaEdicao!!.id
                service.atualizar(id, request).enqueue(object : Callback<Categoria> {
                    override fun onResponse(call: Call<Categoria>, response: Response<Categoria>) {
                        if (response.isSuccessful) {
                            Toast.makeText(this@CategoriaFormActivity, "Categoria atualizada com sucesso!", Toast.LENGTH_SHORT).show()
                            finish()
                        } else {
                            Toast.makeText(this@CategoriaFormActivity, "Erro ao atualizar categoria.", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<Categoria>, t: Throwable) {
                        Toast.makeText(this@CategoriaFormActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
                    }
                })
            }
        }
    }
}