package com.example.futuremob_admin.service

import com.example.futuremob_admin.models.Categoria
import com.example.futuremob_admin.models.CategoriaRequest
import retrofit2.Call
import retrofit2.http.*

interface CategoriaService {

    @GET("categorias/todos")
    fun listarTodas(): Call<List<Categoria>>

    @GET("categorias/{id}")
    fun buscarPorId(@Path("id") id: Int): Call<Categoria>

    @POST("categorias/criar")
    fun criar(@Body categoria: CategoriaRequest): Call<Categoria>

    @PUT("categorias/atualizar/{id}")
    fun atualizar(
        @Path("id") id: Int,
        @Body categoria: CategoriaRequest
    ): Call<Categoria>
}