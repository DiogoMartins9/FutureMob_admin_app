package com.example.futuremob_admin

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.Categoria
import com.example.futuremob_admin.service.CategoriaService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class CategoriasActivity : AppCompatActivity() {

    private lateinit var rvCategorias: RecyclerView
    private lateinit var adapter: CategoriaAdapter
    private var listaCategorias: MutableList<Categoria> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categorias)

        rvCategorias = findViewById(R.id.rvCategorias)
        rvCategorias.layoutManager = LinearLayoutManager(this)

        val txtRodape = findViewById<TextView>(R.id.txtRodapeCategorias)
        val txtDataHora = findViewById<TextView>(R.id.txtDataHoraCategorias)
        val btnVoltar = findViewById<TextView>(R.id.btnVoltarCategorias)
        val btnAdicionar = findViewById<Button>(R.id.btnAdicionarCategoria)
        val edtBuscar = findViewById<EditText>(R.id.edtBuscarCategoria)

        // Data/hora
        val sdf = SimpleDateFormat("dd 'de' MMMM 'de' yyyy - HH:mm", Locale("pt", "BR"))
        txtDataHora.text = sdf.format(Date())

        adapter = CategoriaAdapter(listaCategorias,
            onEditar = { categoria ->
                CategoriaFormActivity.startEditar(this, categoria)
            },
            onExcluir = { _ ->
                Toast.makeText(this, "Exclusão ainda não implementada no app.", Toast.LENGTH_SHORT).show()
            }
        )

        rvCategorias.adapter = adapter

        btnVoltar.setOnClickListener { finish() }

        btnAdicionar.setOnClickListener {
            CategoriaFormActivity.startAdicionar(this)
        }

        // (Busca ainda sem implementação – pode adicionar filtro depois)

        carregarCategorias(txtRodape)
    }

    override fun onResume() {
        super.onResume()
        // Atualiza a lista quando volta da tela de formulário
        val txtRodape = findViewById<TextView>(R.id.txtRodapeCategorias)
        carregarCategorias(txtRodape)
    }

    private fun carregarCategorias(txtRodape: TextView) {
        val service = ClientRetrofit.instance.create(CategoriaService::class.java)

        service.listarTodas().enqueue(object : Callback<List<Categoria>> {
            override fun onResponse(
                call: Call<List<Categoria>>,
                response: Response<List<Categoria>>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    listaCategorias.clear()
                    listaCategorias.addAll(response.body()!!)
                    adapter.notifyDataSetChanged()
                    txtRodape.text = "Exibindo ${listaCategorias.size} registro(s)"
                } else {
                    Toast.makeText(this@CategoriasActivity, "Erro ao carregar categorias.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<Categoria>>, t: Throwable) {
                Toast.makeText(this@CategoriasActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}