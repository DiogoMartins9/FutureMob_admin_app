package com.example.futuremob_admin.models

data class CategoriaRequest(
    val nome: String,
    val descricao: String,
    val caminhoIcone: String?
)