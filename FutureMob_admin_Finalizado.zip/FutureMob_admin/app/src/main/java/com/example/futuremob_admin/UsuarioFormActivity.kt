package com.example.futuremob_admin

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.futuremob_admin.models.UsuarioRequest
import com.example.futuremob_admin.models.UsuarioResponse
import com.example.futuremob_admin.service.UsuarioService
import com.google.android.material.textfield.TextInputEditText
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Calendar

class UsuarioFormActivity : AppCompatActivity() {

    private lateinit var edtNomeCompleto: TextInputEditText
    private lateinit var edtCpf: TextInputEditText
    private lateinit var edtRg: TextInputEditText
    private lateinit var edtDataNascimento: TextInputEditText
    private lateinit var spnSexo: AutoCompleteTextView
    private lateinit var edtTelefoneCelular: TextInputEditText
    private lateinit var swtAdmin: Switch
    private lateinit var edtCaminhoImagem: TextInputEditText
    private lateinit var edtEmail: TextInputEditText
    private lateinit var edtSenha: TextInputEditText
    private lateinit var btnCancelar: Button
    private lateinit var btnConfirmar: Button
    private lateinit var progress: ProgressBar

    private lateinit var service: UsuarioService
    private var idUsuarioEdicao: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_usuario_form)

        edtNomeCompleto = findViewById(R.id.edtNomeCompleto)
        edtCpf = findViewById(R.id.edtCpf)
        edtRg = findViewById(R.id.edtRg)
        edtDataNascimento = findViewById(R.id.edtDataNascimento)
        spnSexo = findViewById(R.id.spnSexo)
        edtTelefoneCelular = findViewById(R.id.edtTelefoneCelular)
        swtAdmin = findViewById(R.id.swtAdmin)
        edtCaminhoImagem = findViewById(R.id.edtCaminhoImagem)
        edtEmail = findViewById(R.id.edtEmail)
        edtSenha = findViewById(R.id.edtSenha)
        btnCancelar = findViewById(R.id.btnCancelarUsuario)
        btnConfirmar = findViewById(R.id.btnConfirmarUsuario)
        progress = findViewById(R.id.progressUsuarioForm)

        service = ClientRetrofit.instance.create(UsuarioService::class.java)

        configurarSexo()
        configurarDataNascimento()

        idUsuarioEdicao = intent.getIntExtra("idUsuario", -1).takeIf { it > 0 }

        if (idUsuarioEdicao != null) {
            carregarUsuario(idUsuarioEdicao!!)
            title = "Editar Usuário"
        } else {
            title = "Novo Usuário"
        }

        btnCancelar.setOnClickListener {
            finish()
        }

        btnConfirmar.setOnClickListener {
            salvarUsuario()
        }
    }

    private fun configurarSexo() {
        val opcoes = listOf("Masculino", "Feminino", "Outro")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, opcoes)
        spnSexo.setAdapter(adapter)
    }

    private fun configurarDataNascimento() {
        edtDataNascimento.setOnClickListener {
            abrirDatePicker()
        }
    }

    private fun abrirDatePicker() {
        val cal = Calendar.getInstance()
        val ano = cal.get(Calendar.YEAR)
        val mes = cal.get(Calendar.MONTH)
        val dia = cal.get(Calendar.DAY_OF_MONTH)

        val dialog = DatePickerDialog(this, { _, y, m, d ->
            val diaStr = d.toString().padStart(2, '0')
            val mesStr = (m + 1).toString().padStart(2, '0')
            edtDataNascimento.setText("$diaStr/$mesStr/$y")
        }, ano, mes, dia)

        dialog.show()
    }

    private fun carregarUsuario(id: Int) {
        progress.visibility = View.VISIBLE
        service.buscarPorId(id).enqueue(object : Callback<UsuarioResponse> {
            override fun onResponse(
                call: Call<UsuarioResponse>,
                response: Response<UsuarioResponse>
            ) {
                progress.visibility = View.GONE
                if (response.isSuccessful && response.body() != null) {
                    val u = response.body()!!
                    edtNomeCompleto.setText(u.nome)
                    edtCpf.setText(u.cpf)
                    edtRg.setText(u.rg)
                    edtDataNascimento.setText(u.dataNascimento)
                    spnSexo.setText(u.sexo, false)
                    edtTelefoneCelular.setText(u.telefoneCelular)
                    swtAdmin.isChecked = u.admin
                    edtEmail.setText(u.email)
                } else {
                    Toast.makeText(this@UsuarioFormActivity, "Erro ao carregar usuário", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }

            override fun onFailure(call: Call<UsuarioResponse>, t: Throwable) {
                progress.visibility = View.GONE
                Toast.makeText(this@UsuarioFormActivity, "Falha na comunicação com o servidor", Toast.LENGTH_SHORT).show()
                finish()
            }
        })
    }

    private fun montarRequest(): UsuarioRequest {
        val nome = edtNomeCompleto.text.toString().trim()
        val cpf = edtCpf.text.toString().trim()
        val rg = edtRg.text.toString().trim()
        val dataNascimento = edtDataNascimento.text.toString().trim()
        val sexo = spnSexo.text.toString().trim()
        val telefone = edtTelefoneCelular.text.toString().trim()
        val admin = swtAdmin.isChecked
        val caminhoImagem = edtCaminhoImagem.text.toString().trim()
        val email = edtEmail.text.toString().trim()
        val senha = edtSenha.text.toString()

        return UsuarioRequest(
            nome = nome,
            cpf = cpf,
            rg = rg,
            dataNascimento = dataNascimento,
            sexo = sexo,
            telefoneCelular = telefone,
            admin = admin,
            caminhoImagemPerfil = caminhoImagem,
            email = email,
            senha = senha
        )
    }

    private fun salvarUsuario() {
        val request = montarRequest()
        progress.visibility = View.VISIBLE
        btnConfirmar.isEnabled = false

        val call = if (idUsuarioEdicao != null) {
            service.atualizar(idUsuarioEdicao!!, request)
        } else {
            service.criar(request)
        }

        call.enqueue(object : Callback<UsuarioResponse> {
            override fun onResponse(
                call: Call<UsuarioResponse>,
                response: Response<UsuarioResponse>
            ) {
                progress.visibility = View.GONE
                btnConfirmar.isEnabled = true
                if (response.isSuccessful) {
                    Toast.makeText(this@UsuarioFormActivity, "Usuário salvo com sucesso", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@UsuarioFormActivity, "Erro ao salvar usuário", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<UsuarioResponse>, t: Throwable) {
                progress.visibility = View.GONE
                btnConfirmar.isEnabled = true
                Toast.makeText(this@UsuarioFormActivity, "Falha na comunicação com o servidor", Toast.LENGTH_SHORT).show()
            }
        })
    }
}