package com.example.futuremob_admin.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class CategoriaResponse(
    @SerializedName("idCategoria") val idCategoria: Int,
    @SerializedName("nome") val nome: String,
    @SerializedName("descricao") val descricao: String,
    @SerializedName("caminhoIcone") val caminhoIcone: String
) : Serializable