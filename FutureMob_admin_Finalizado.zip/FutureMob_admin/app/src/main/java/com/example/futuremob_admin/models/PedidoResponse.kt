package com.example.futuremob_admin.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class PedidoResponse(

    @SerializedName("idPedido")
    val idPedido: Int,

    @SerializedName("dtPedido")
    val dtPedido: String,

    @SerializedName("dtEntrega")
    val dtEntrega: String?,

    @SerializedName("subtotal")
    val subtotal: Double,

    @SerializedName("frete")
    val frete: Double,

    @SerializedName("total")
    val total: Double,

    @SerializedName("statusPedido")
    val statusPedido: String,

    @SerializedName("formaPagamento")
    val formaPagamento: String,

    @SerializedName("numeroCartao")
    val numeroCartao: String?,

    @SerializedName("parcelas")
    val parcelas: Int?,

    @SerializedName("endereco")
    val endereco: String?,              // quando compra é para entrega

    @SerializedName("enderecoLoja")
    val enderecoLoja: String?,          // quando retirada na loja

    @SerializedName("email")
    val email: String,

    @SerializedName("telefoneCelular")
    val telefoneCelular: String,

    @SerializedName("nomeCompleto")
    val nomeCompleto: String,

    @SerializedName("produtosPorPedido")
    val produtosPorPedido: List<ProdutoPedidoResponse>
) : Serializable