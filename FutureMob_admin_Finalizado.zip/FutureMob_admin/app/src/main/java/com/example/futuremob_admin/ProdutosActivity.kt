package com.example.futuremob_admin

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.ProdutoResponse
import com.example.futuremob_admin.service.ProdutoService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class ProdutosActivity : AppCompatActivity() {

    private val listaProdutos = mutableListOf<ProdutoResponse>()
    private val listaFiltrada = mutableListOf<ProdutoResponse>()
    private lateinit var adapter: ProdutoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_produtos)

        val btnVoltar = findViewById<TextView>(R.id.btnVoltarProdutos)
        val btnAdicionar = findViewById<Button>(R.id.btnAdicionarProduto)
        val edtBuscar = findViewById<EditText>(R.id.edtBuscarProduto)
        val rvProdutos = findViewById<RecyclerView>(R.id.rvProdutos)

        val dataHoraAtual = SimpleDateFormat("dd 'de' MMMM 'de' yyyy - HH:mm", Locale("pt", "BR"))

        rvProdutos.layoutManager = LinearLayoutManager(this)
        adapter = ProdutoAdapter(listaFiltrada,
            onEditar = { produto ->
                val intent = Intent(this, ProdutoFormActivity::class.java)
                intent.putExtra("produto", produto)
                startActivity(intent)
            },
            onExcluir = { produto ->
                excluirProduto(produto.id)
            }
        )
        rvProdutos.adapter = adapter

        btnVoltar.setOnClickListener {
            finish()
        }

        btnAdicionar.setOnClickListener {
            val intent = Intent(this, ProdutoFormActivity::class.java)
            startActivity(intent)
        }

        edtBuscar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filtrar(s?.toString() ?: "")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        carregarProdutos()
    }

    private fun carregarProdutos() {
        val retrofit = ClientRetrofit.instance
        val service = retrofit.create(ProdutoService::class.java)
        service.listarTodos().enqueue(object : Callback<List<ProdutoResponse>> {
            override fun onResponse(call: Call<List<ProdutoResponse>>, response: Response<List<ProdutoResponse>>) {
                if (response.isSuccessful && response.body() != null) {
                    listaProdutos.clear()
                    listaProdutos.addAll(response.body()!!)
                    filtrar("")
                } else {
                    Toast.makeText(this@ProdutosActivity, "Erro ao carregar produtos.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<ProdutoResponse>>, t: Throwable) {
                Toast.makeText(this@ProdutosActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun filtrar(termo: String) {
        listaFiltrada.clear()
        if (termo.isBlank()) {
            listaFiltrada.addAll(listaProdutos)
        } else {
            val termoLower = termo.lowercase(Locale.getDefault())
            listaFiltrada.addAll(
                listaProdutos.filter {
                    it.nome.lowercase(Locale.getDefault()).contains(termoLower) ||
                            it.descricao.lowercase(Locale.getDefault()).contains(termoLower)
                }
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun excluirProduto(id: Int) {
        val retrofit = ClientRetrofit.instance
        val service = retrofit.create(ProdutoService::class.java)
        service.excluir(id).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@ProdutosActivity, "Produto excluído com sucesso.", Toast.LENGTH_SHORT).show()
                    carregarProdutos()
                } else {
                    Toast.makeText(this@ProdutosActivity, "Erro ao excluir produto.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Toast.makeText(this@ProdutosActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}