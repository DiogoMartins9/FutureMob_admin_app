package com.example.futuremob_admin

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.CategoriaResponse
import com.example.futuremob_admin.service.CategoriaService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class CategoriasActivity : AppCompatActivity() {

    private val listaCategorias = mutableListOf<CategoriaResponse>()
    private val listaFiltrada = mutableListOf<CategoriaResponse>()
    private lateinit var adapter: CategoriaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categorias)

        val btnVoltar = findViewById<TextView>(R.id.btnVoltarCategorias)
        val btnAdicionar = findViewById<Button>(R.id.btnAdicionarCategoria)
        val edtBuscar = findViewById<EditText>(R.id.edtBuscarCategoria)
        val rvCategorias = findViewById<RecyclerView>(R.id.rvCategorias)

        val dataHoraAtual = SimpleDateFormat("dd 'de' MMMM 'de' yyyy - HH:mm", Locale("pt", "BR"))

        rvCategorias.layoutManager = LinearLayoutManager(this)
        adapter = CategoriaAdapter(
            listaFiltrada,
            onEditar = { categoria ->
                val intent = Intent(this, CategoriaFormActivity::class.java)
                intent.putExtra("categoria", categoria)
                startActivity(intent)
            },
            onExcluir = { categoria ->
                excluirCategoria(categoria.idCategoria)
            }
        )
        rvCategorias.adapter = adapter

        btnVoltar.setOnClickListener {
            finish()
        }

        btnAdicionar.setOnClickListener {
            val intent = Intent(this, CategoriaFormActivity::class.java)
            startActivity(intent)
        }

        edtBuscar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filtrar(s?.toString() ?: "")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        carregarCategorias()
    }

    private fun carregarCategorias() {
        val service = ClientRetrofit.instance.create(CategoriaService::class.java)

        service.listarTodas().enqueue(object : Callback<List<CategoriaResponse>> {
            override fun onResponse(
                call: Call<List<CategoriaResponse>>,
                response: Response<List<CategoriaResponse>>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    listaCategorias.clear()
                    listaCategorias.addAll(response.body()!!)
                    filtrar("")
                } else {
                    Toast.makeText(this@CategoriasActivity, "Erro ao carregar categorias.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<CategoriaResponse>>, t: Throwable) {
                Toast.makeText(this@CategoriasActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun filtrar(termo: String) {
        listaFiltrada.clear()
        if (termo.isBlank()) {
            listaFiltrada.addAll(listaCategorias)
        } else {
            val termoLower = termo.lowercase(Locale.getDefault())
            listaFiltrada.addAll(
                listaCategorias.filter {
                    it.nome.lowercase(Locale.getDefault()).contains(termoLower) ||
                            it.descricao.lowercase(Locale.getDefault()).contains(termoLower)
                }
            )
        }
        adapter.notifyDataSetChanged()
    }

    private fun excluirCategoria(id: Int) {
        val service = ClientRetrofit.instance.create(CategoriaService::class.java)
        service.excluir(id).enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@CategoriasActivity, "Categoria excluída com sucesso.", Toast.LENGTH_SHORT).show()
                    carregarCategorias()
                } else {
                    Toast.makeText(this@CategoriasActivity, "Erro ao excluir categoria.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Toast.makeText(this@CategoriasActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}