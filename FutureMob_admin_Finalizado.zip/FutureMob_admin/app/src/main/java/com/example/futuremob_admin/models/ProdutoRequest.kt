package com.example.futuremob_admin.models

data class ProdutoRequest(
    val nome: String,
    val descricao: String,
    val precoAnterior: Double,
    val precoAtual: Double,
    val altura: Double,
    val largura: Double,
    val profundidade: Double,
    val peso: Double,
    val destaque: Boolean,
    val ofertaRelampago: Boolean,
    val categoria: CategoriaIdRequest,
    val caminhoImagem: String?,
    val ativo: Boolean
)