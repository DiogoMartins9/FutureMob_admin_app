package com.example.futuremob_admin.service

import com.example.futuremob_admin.models.LoginRequest
import com.example.futuremob_admin.models.UsuarioRequest
import com.example.futuremob_admin.models.UsuarioResponse
import retrofit2.Call
import retrofit2.http.*

interface UsuarioService {

    @POST("usuarios/autenticar")
    fun login(@Body login: LoginRequest): Call<UsuarioResponse>

    @GET("usuarios/todos")
    fun listarUsuarios(): Call<List<UsuarioResponse>>

    @GET("usuarios/{id}")
    fun buscarPorId(@Path("id") id: Int): Call<UsuarioResponse>

    @POST("usuarios/criar")
    fun criar(@Body request: UsuarioRequest): Call<UsuarioResponse>

    @PUT("usuarios/atualizar/{id}")
    fun atualizar(
        @Path("id") id: Int,
        @Body request: UsuarioRequest
    ): Call<UsuarioResponse>

    //@DELETE("usuarios/{id}")
    //fun remover(@Path("id") id: Int): Call<UsuarioResponse>

    @PUT("usuarios/{id}/ativar-desativar")
    fun ativarDesativar(@Path("id") id: Int): Call<UsuarioResponse>

}
