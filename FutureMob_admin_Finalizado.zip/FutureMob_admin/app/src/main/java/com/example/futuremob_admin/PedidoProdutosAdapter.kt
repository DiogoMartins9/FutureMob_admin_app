package com.example.futuremob_admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.ProdutoPedidoResponse

class PedidoProdutosAdapter(
    private val produtos: List<ProdutoPedidoResponse>,
    private val onAbrirProduto: (ProdutoPedidoResponse) -> Unit
) : RecyclerView.Adapter<PedidoProdutosAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtNome: TextView = view.findViewById(R.id.txtNomeProdutoPedido)
        val txtCategoria: TextView = view.findViewById(R.id.txtCategoriaProdutoPedido)
        val txtPreco: TextView = view.findViewById(R.id.txtPrecoProdutoPedido)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_produto_pedido, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val produto = produtos[position]

        holder.txtNome.text = produto.nome
        holder.txtCategoria.text = produto.categoriaNome ?: "Sem categoria"
        holder.txtPreco.text = "R$ %.2f".format(produto.precoAtual)

        holder.itemView.setOnClickListener { onAbrirProduto(produto) }
    }

    override fun getItemCount(): Int = produtos.size
}