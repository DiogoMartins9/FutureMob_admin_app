package com.example.futuremob_admin.service

import com.example.futuremob_admin.models.PedidoResponse
import retrofit2.Call
import retrofit2.http.GET

interface PedidoService {

    @GET("pedidos/todos")
    fun listarTodos(): Call<List<PedidoResponse>>
}