package com.example.futuremob_admin.service

import com.example.futuremob_admin.models.ProdutoRequest
import com.example.futuremob_admin.models.ProdutoResponse
import retrofit2.Call
import retrofit2.http.*

interface ProdutoService {
    @GET("produtos/todos")
    fun listarTodos(): Call<List<ProdutoResponse>>

    @GET("produtos/{id}")
    fun buscarPorId(@Path("id") id: Int): Call<ProdutoResponse>

    @POST("produtos/criar")
    fun criar(@Body produto: ProdutoRequest): Call<ProdutoResponse>

    @PUT("produtos/atualizar/{id}")
    fun atualizar(
        @Path("id") id: Int,
        @Body produto: ProdutoRequest
    ): Call<ProdutoResponse>

    @DELETE("produtos/{id}")
    fun excluir(@Path("id") id: Int): Call<Void>
}