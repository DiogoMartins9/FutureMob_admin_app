package com.example.futuremob_admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.ProdutoResponse

class ProdutoAdapter(
    private val produtos: List<ProdutoResponse>,
    private val onEditar: (ProdutoResponse) -> Unit,
    private val onExcluir: (ProdutoResponse) -> Unit
) : RecyclerView.Adapter<ProdutoAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtId: TextView = view.findViewById(R.id.txtIdProduto)
        val txtNome: TextView = view.findViewById(R.id.txtNomeProduto)
        val txtPreco: TextView = view.findViewById(R.id.txtPrecoProduto)
        val txtCategoria: TextView = view.findViewById(R.id.txtCategoriaProduto)
        val btnExcluir: ImageButton = view.findViewById(R.id.btnExcluirProduto)
        val btnEditar: ImageButton = view.findViewById(R.id.btnEditarProduto)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_produto, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = produtos.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val produto = produtos[position]
        holder.txtId.text = produto.id.toString()
        holder.txtNome.text = produto.nome
        holder.txtPreco.text = "R$ %.2f".format(produto.precoAtual)
        holder.txtCategoria.text = "Categoria: ${produto.categoria?.nome ?: "-"}"
        holder.btnEditar.setOnClickListener { onEditar(produto) }
        holder.btnExcluir.setOnClickListener { onExcluir(produto) }
    }
}