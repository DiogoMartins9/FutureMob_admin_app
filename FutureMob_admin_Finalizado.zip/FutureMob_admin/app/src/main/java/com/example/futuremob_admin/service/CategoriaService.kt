package com.example.futuremob_admin.service

import com.example.futuremob_admin.models.CategoriaRequest
import com.example.futuremob_admin.models.CategoriaResponse
import retrofit2.Call
import retrofit2.http.*

interface CategoriaService {

    @GET("categorias/todos")
    fun listarTodas(): Call<List<CategoriaResponse>>

    @GET("categorias/{id}")
    fun buscarPorId(@Path("id") id: Int): Call<CategoriaResponse>

    @POST("categorias/criar")
    fun criar(@Body categoria: CategoriaRequest): Call<CategoriaResponse>

    @PUT("categorias/atualizar/{id}")
    fun atualizar(
        @Path("id") id: Int,
        @Body categoria: CategoriaRequest
    ): Call<CategoriaResponse>

    @DELETE("categorias/{id}")
    fun excluir(@Path("id") id: Int): Call<Void>

}