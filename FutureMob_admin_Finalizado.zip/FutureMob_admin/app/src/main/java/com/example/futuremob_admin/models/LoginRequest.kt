package com.example.futuremob_admin.models

data class LoginRequest(
    val email: String,
    val senha: String)
