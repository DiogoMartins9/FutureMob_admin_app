package com.example.futuremob_admin.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ProdutoResponse(
    @SerializedName("idProduto") val id: Int,
    @SerializedName("nome") val nome: String,
    @SerializedName("descricao") val descricao: String,
    @SerializedName("precoAnterior") val precoAnterior: Double,
    @SerializedName("precoAtual") val precoAtual: Double,
    @SerializedName("altura") val altura: Double,
    @SerializedName("largura") val largura: Double,
    @SerializedName("profundidade") val profundidade: Double,
    @SerializedName("peso") val peso: Double,
    @SerializedName("destaque") val destaque: Boolean,
    @SerializedName("ofertaRelampago") val ofertaRelampago: Boolean,
    @SerializedName("categoria") val categoria: CategoriaResponse,
    @SerializedName("caminhoImagem") val caminhoImagem: String?,
    @SerializedName("ativo") val ativo: Boolean,
    @SerializedName("dataCadastro") val dataCadastro: String
) : Serializable