package com.example.futuremob_admin.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ProdutoPedidoResponse(

    @SerializedName("idProduto")
    val idProduto: Int,

    @SerializedName("nome")
    val nome: String,

    @SerializedName("precoAnterior")
    val precoAnterior: Double,

    @SerializedName("precoAtual")
    val precoAtual: Double,

    @SerializedName("caminhoImagem")
    val caminhoImagem: String,

    @SerializedName("categoriaNome")
    val categoriaNome: String?,

    @SerializedName("destaque")
    val destaque: Boolean,

    @SerializedName("ofertaRelampago")
    val ofertaRelampago: Boolean
) : Serializable