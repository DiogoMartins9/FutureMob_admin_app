package com.example.futuremob_admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.PedidoResponse

class PedidoAdapter(
    private val pedidos: MutableList<PedidoResponse>,
    private val onDetalhes: (PedidoResponse) -> Unit,
    private val onProdutos: (PedidoResponse) -> Unit
) : RecyclerView.Adapter<PedidoAdapter.PedidoViewHolder>() {

    class PedidoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtId: TextView = view.findViewById(R.id.txtIdPedido)
        val txtData: TextView = view.findViewById(R.id.txtDataPedido)
        val txtCliente: TextView = view.findViewById(R.id.txtClientePedido)
        val txtStatus: TextView = view.findViewById(R.id.txtStatusPedido)
        val txtEntrega: TextView = view.findViewById(R.id.txtEntregaPedido)
        val txtValores: TextView = view.findViewById(R.id.txtValoresPedido)
        val btnDetalhes: ImageButton = view.findViewById(R.id.btnDetalhesPedido)
        val btnProdutos: ImageButton = view.findViewById(R.id.btnProdutosPedido)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PedidoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pedido, parent, false)
        return PedidoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PedidoViewHolder, position: Int) {
        val pedido = pedidos[position]

        holder.txtId.text = "ID: ${pedido.idPedido}"
        holder.txtData.text = "Data Pedido: ${pedido.dtPedido}"
        holder.txtCliente.text = "Cliente: ${pedido.nomeCompleto}"
        holder.txtStatus.text = "Status: ${pedido.statusPedido}"

        val entrega = pedido.dtEntrega ?: "Não definida."
        holder.txtEntrega.text = "Dt. Entrega: $entrega"

        holder.txtValores.text = "Subtotal: R$ %.2f | Frete: R$ %.2f | Total: R$ %.2f"
            .format(pedido.subtotal, pedido.frete, pedido.total)

        holder.btnDetalhes.setOnClickListener { onDetalhes(pedido) }
        holder.btnProdutos.setOnClickListener { onProdutos(pedido) }
    }

    override fun getItemCount(): Int = pedidos.size

    fun atualizarLista(novaLista: List<PedidoResponse>) {
        pedidos.clear()
        pedidos.addAll(novaLista)
        notifyDataSetChanged()
    }
}