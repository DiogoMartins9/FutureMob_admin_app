package com.example.futuremob_admin

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.UsuarioResponse

class UsuarioAdapter(
    private val usuarios: MutableList<UsuarioResponse>,
    private val onEditar: (UsuarioResponse) -> Unit,
    private val onAtivarDesativar: (UsuarioResponse) -> Unit
) : RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder>() {

    inner class UsuarioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtNome: TextView = itemView.findViewById(R.id.txtNomeUsuario)
        val txtEmail: TextView = itemView.findViewById(R.id.txtEmailUsuario)
        val txtTelefone: TextView = itemView.findViewById(R.id.txtTelefoneUsuario)
        val txtAdmin: TextView = itemView.findViewById(R.id.txtAdminUsuario)
        val txtId: TextView = itemView.findViewById(R.id.txtIdUsuario)
        val btnAtivarDesativar: ImageButton = itemView.findViewById(R.id.btnExcluirUsuario)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_usuario, parent, false)
        return UsuarioViewHolder(view)
    }

    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        val usuario = usuarios[position]
        holder.txtId.text = usuario.id.toString()
        holder.txtNome.text = usuario.nome
        holder.txtEmail.text = usuario.email
        holder.txtTelefone.text = usuario.telefoneCelular
        holder.txtAdmin.text = if (usuario.admin) "Sim" else "Não"

        if (usuario.ativo) {
            holder.btnAtivarDesativar.setImageResource(R.drawable.ic_desativar)
            holder.btnAtivarDesativar.contentDescription = "Desativar usuário"
        } else {
            holder.btnAtivarDesativar.setImageResource(R.drawable.ic_ativar)
            holder.btnAtivarDesativar.contentDescription = "Ativar usuário"
        }

        holder.itemView.setOnClickListener {
            onEditar(usuario)
        }

        holder.btnAtivarDesativar.setOnClickListener {
            onAtivarDesativar(usuario)
        }
    }

    override fun getItemCount(): Int = usuarios.size

    fun atualizarLista(novaLista: List<UsuarioResponse>) {
        usuarios.clear()
        usuarios.addAll(novaLista)
        notifyDataSetChanged()
    }
}
