package com.example.futuremob_admin.models

data class CategoriaIdRequest(
    val idCategoria: Int
)