package com.example.futuremob_admin

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.futuremob_admin.models.CategoriaIdRequest
import com.example.futuremob_admin.models.ProdutoRequest
import com.example.futuremob_admin.models.ProdutoResponse
import com.example.futuremob_admin.service.ProdutoService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class ProdutoFormActivity : AppCompatActivity() {

    private var produtoEdicao: ProdutoResponse? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_produto_form)

        val txtTituloPainel = findViewById<TextView>(R.id.txtTituloPainelFormProduto)
        val txtDataHora = findViewById<TextView>(R.id.txtDataHoraFormProduto)
        val txtTituloSecao = findViewById<TextView>(R.id.txtTituloSecaoFormProduto)

        val edtNome = findViewById<EditText>(R.id.edtNomeProduto)
        val edtDescricao = findViewById<EditText>(R.id.edtDescricaoProduto)
        val edtPrecoAnterior = findViewById<EditText>(R.id.edtPrecoAnteriorProduto)
        val edtPrecoAtual = findViewById<EditText>(R.id.edtPrecoAtualProduto)
        val edtAltura = findViewById<EditText>(R.id.edtAlturaProduto)
        val edtLargura = findViewById<EditText>(R.id.edtLarguraProduto)
        val edtProfundidade = findViewById<EditText>(R.id.edtProfundidadeProduto)
        val edtPeso = findViewById<EditText>(R.id.edtPesoProduto)
        val edtIdCategoria = findViewById<EditText>(R.id.edtIdCategoriaProduto)
        val edtCaminhoImagem = findViewById<EditText>(R.id.edtCaminhoImagemProduto)
        val chkDestaque = findViewById<CheckBox>(R.id.chkDestaqueProduto)
        val chkOfertaRelampago = findViewById<CheckBox>(R.id.chkOfertaRelampagoProduto)
        val chkAtivo = findViewById<CheckBox>(R.id.chkAtivoProduto)

        val btnCancelar = findViewById<Button>(R.id.btnCancelarProduto)
        val btnConfirmar = findViewById<Button>(R.id.btnConfirmarProduto)

        txtTituloPainel.text = "Painel Administrativo"
        val dataHoraAtual = SimpleDateFormat("dd 'de' MMMM 'de' yyyy - HH:mm", Locale("pt", "BR"))
        txtDataHora.text = dataHoraAtual.format(Date())

        val extra = intent.getSerializableExtra("produto")
        if (extra is ProdutoResponse) {
            produtoEdicao = extra
            txtTituloSecao.text = "Editar produto"
            edtNome.setText(extra.nome)
            edtDescricao.setText(extra.descricao)
            edtPrecoAnterior.setText(extra.precoAnterior.toString())
            edtPrecoAtual.setText(extra.precoAtual.toString())
            edtAltura.setText(extra.altura.toString())
            edtLargura.setText(extra.largura.toString())
            edtProfundidade.setText(extra.profundidade.toString())
            edtPeso.setText(extra.peso.toString())
            edtIdCategoria.setText(extra.categoria.idCategoria.toString())
            edtCaminhoImagem.setText(extra.caminhoImagem ?: "")
            chkDestaque.isChecked = extra.destaque
            chkOfertaRelampago.isChecked = extra.ofertaRelampago
            chkAtivo.isChecked = extra.ativo
        } else {
            txtTituloSecao.text = "Novo produto"
            chkAtivo.isChecked = true
        }

        btnCancelar.setOnClickListener {
            finish()
        }

        btnConfirmar.setOnClickListener {
            val nome = edtNome.text.toString().trim()
            val descricao = edtDescricao.text.toString().trim()
            val precoAnterior = edtPrecoAnterior.text.toString().replace(",", ".").toDoubleOrNull()
            val precoAtual = edtPrecoAtual.text.toString().replace(",", ".").toDoubleOrNull()
            val altura = edtAltura.text.toString().replace(",", ".").toDoubleOrNull()
            val largura = edtLargura.text.toString().replace(",", ".").toDoubleOrNull()
            val profundidade = edtProfundidade.text.toString().replace(",", ".").toDoubleOrNull()
            val peso = edtPeso.text.toString().replace(",", ".").toDoubleOrNull()
            val idCategoria = edtIdCategoria.text.toString().toIntOrNull()

            if (nome.isBlank() || descricao.isBlank() || precoAnterior == null || precoAtual == null ||
                altura == null || largura == null || profundidade == null || peso == null || idCategoria == null
            ) {
                Toast.makeText(this, "Preencha todos os campos obrigatórios.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val caminhoImagem = edtCaminhoImagem.text.toString().trim().ifBlank { null }
            val destaque = chkDestaque.isChecked
            val ofertaRelampago = chkOfertaRelampago.isChecked
            val ativo = chkAtivo.isChecked

            val request = ProdutoRequest(
                nome = nome,
                descricao = descricao,
                precoAnterior = precoAnterior,
                precoAtual = precoAtual,
                altura = altura,
                largura = largura,
                profundidade = profundidade,
                peso = peso,
                destaque = destaque,
                ofertaRelampago = ofertaRelampago,
                categoria = CategoriaIdRequest(idCategoria),
                caminhoImagem = caminhoImagem,
                ativo = ativo
            )

            val retrofit = ClientRetrofit.instance
            val service = retrofit.create(ProdutoService::class.java)

            val call: Call<ProdutoResponse> = if (produtoEdicao == null) {
                service.criar(request)
            } else {
                service.atualizar(produtoEdicao!!.id, request)
            }

            call.enqueue(object : Callback<ProdutoResponse> {
                override fun onResponse(call: Call<ProdutoResponse>, response: Response<ProdutoResponse>) {
                    if (response.isSuccessful) {
                        if (produtoEdicao == null) {
                            Toast.makeText(this@ProdutoFormActivity, "Produto criado com sucesso!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@ProdutoFormActivity, "Produto atualizado com sucesso!", Toast.LENGTH_SHORT).show()
                        }
                        finish()
                    } else {
                        if (produtoEdicao == null) {
                            Toast.makeText(this@ProdutoFormActivity, "Erro ao criar produto.", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@ProdutoFormActivity, "Erro ao atualizar produto.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                override fun onFailure(call: Call<ProdutoResponse>, t: Throwable) {
                    Toast.makeText(this@ProdutoFormActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
        }
    }
}