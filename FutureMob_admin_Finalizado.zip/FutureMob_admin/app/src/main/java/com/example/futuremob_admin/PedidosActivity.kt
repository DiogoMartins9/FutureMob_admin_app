package com.example.futuremob_admin

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.PedidoResponse
import com.example.futuremob_admin.models.ProdutoPedidoResponse
import com.example.futuremob_admin.service.PedidoService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class PedidosActivity : AppCompatActivity() {

    private val listaPedidos = mutableListOf<PedidoResponse>()
    private val listaFiltrada = mutableListOf<PedidoResponse>()
    private lateinit var adapter: PedidoAdapter
    private lateinit var txtRodape: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pedidos)


        val txtTituloPainel = findViewById<TextView>(R.id.txtTituloPainelPedidos)
        val txtDataHora = findViewById<TextView>(R.id.txtDataHoraPedidos)
        val btnVoltar = findViewById<Button>(R.id.btnVoltarPedidos)
        val edtBuscar = findViewById<EditText>(R.id.edtBuscarPedido)
        val rvPedidos = findViewById<RecyclerView>(R.id.rvPedidos)
        txtRodape = findViewById(R.id.txtRodapePedidos)


        txtTituloPainel.text = "Painel Administrativo"
        val dataHoraAtual = SimpleDateFormat(
            "dd 'de' MMMM 'de' yyyy - HH:mm",
            Locale("pt", "BR")
        )
        txtDataHora.text = dataHoraAtual.format(Date())


        rvPedidos.layoutManager = LinearLayoutManager(this)
        adapter = PedidoAdapter(
            listaFiltrada,
            onDetalhes = { pedido ->
                mostrarDialogDetalhes(pedido)
            },
            onProdutos = { pedido ->
                mostrarDialogProdutos(pedido)
            }
        )
        rvPedidos.adapter = adapter


        btnVoltar.setOnClickListener {
            finish()
        }


        edtBuscar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {
            }

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
            }

            override fun afterTextChanged(s: Editable?) {
                filtrar(s?.toString() ?: "")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        carregarPedidos()
    }


    private fun carregarPedidos() {
        val retrofit = ClientRetrofit.instance
        val service = retrofit.create(PedidoService::class.java)

        service.listarTodos().enqueue(object : Callback<List<PedidoResponse>> {
            override fun onResponse(
                call: Call<List<PedidoResponse>>,
                response: Response<List<PedidoResponse>>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    listaPedidos.clear()
                    listaPedidos.addAll(response.body()!!)
                    filtrar("")
                } else {
                    Toast.makeText(
                        this@PedidosActivity,
                        "Erro ao carregar pedidos.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<PedidoResponse>>, t: Throwable) {
                Toast.makeText(
                    this@PedidosActivity,
                    "Erro: ${t.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }


    private fun filtrar(termo: String) {
        listaFiltrada.clear()
        if (termo.isBlank()) {
            listaFiltrada.addAll(listaPedidos)
        } else {
            val termoLower = termo.lowercase(Locale.getDefault())
            listaFiltrada.addAll(
                listaPedidos.filter { pedido ->
                    pedido.idPedido.toString().contains(termoLower) ||
                            pedido.nomeCompleto.lowercase(Locale.getDefault())
                                .contains(termoLower) ||
                            pedido.statusPedido.lowercase(Locale.getDefault())
                                .contains(termoLower)
                }
            )
        }
        adapter.notifyDataSetChanged()
        txtRodape.text = "Exibindo ${listaFiltrada.size} registro(s)"
    }


    private fun mostrarDialogDetalhes(pedido: PedidoResponse) {
        val view = LayoutInflater.from(this)
            .inflate(R.layout.dialog_detalhes_pedido, null, false)

        val txtTitulo = view.findViewById<TextView>(R.id.txtTituloDetalhesPedido)
        val txtEndereco = view.findViewById<TextView>(R.id.txtEnviarPara)
        val txtFormaPagamento = view.findViewById<TextView>(R.id.txtFormaPagamento)
        val txtEmail = view.findViewById<TextView>(R.id.txtEmailCliente)
        val txtTelefone = view.findViewById<TextView>(R.id.txtTelefoneCliente)
        val btnFechar = view.findViewById<Button>(R.id.btnFecharDetalhesPedido)

        txtTitulo.text = "Detalhes do pedido ${pedido.idPedido}"


        txtEndereco.text = when {
            !pedido.endereco.isNullOrBlank() -> pedido.endereco
            !pedido.enderecoLoja.isNullOrBlank() -> pedido.enderecoLoja
            else -> "Endereço não informado"
        }


        val infoCartao = if (!pedido.numeroCartao.isNullOrBlank()
            && pedido.parcelas != null
        ) {
            "Cartão final ${pedido.numeroCartao.takeLast(4)} (${pedido.parcelas}x)"
        } else {
            pedido.formaPagamento
        }
        txtFormaPagamento.text = infoCartao

        txtEmail.text = pedido.email
        txtTelefone.text = pedido.telefoneCelular

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnFechar.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }


    private fun mostrarDialogProdutos(pedido: PedidoResponse) {
        val view = LayoutInflater.from(this)
            .inflate(R.layout.dialog_produtos_pedido, null, false)

        val txtTitulo = view.findViewById<TextView>(R.id.txtTituloProdutosPedido)
        val rvProdutos = view.findViewById<RecyclerView>(R.id.recyclerProdutosPedido)
        val btnFechar = view.findViewById<Button>(R.id.btnFecharProdutosPedido)

        txtTitulo.text = "Produtos do pedido ${pedido.idPedido}"

        val produtos: List<ProdutoPedidoResponse> = pedido.produtosPorPedido

        val adapterProdutos = PedidoProdutosAdapter(produtos) { produto ->

            val intent = Intent(this, ProdutoFormActivity::class.java)
            intent.putExtra("produtoId", produto.idProduto)
            startActivity(intent)
        }

        rvProdutos.layoutManager = LinearLayoutManager(this)
        rvProdutos.adapter = adapterProdutos

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .create()

        btnFechar.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }
}