package com.example.futuremob_admin.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class UsuarioResponse(
    @SerializedName("idUsuario") val id: Int,
    @SerializedName("nomeCompleto") val nome: String,
    @SerializedName("cpf") val cpf: String,
    @SerializedName("rg") val rg: String,
    @SerializedName("dataNascimento") val dataNascimento: String,
    @SerializedName("sexo") val sexo: String,
    @SerializedName("telefoneCelular") val telefoneCelular: String,
    @SerializedName("email") val email: String,
    @SerializedName("admin") val admin: Boolean,
    @SerializedName("caminhoImgPerfil") val caminhoImgPerfil: String?,
    @SerializedName("ativo") val ativo: Boolean
):Serializable

