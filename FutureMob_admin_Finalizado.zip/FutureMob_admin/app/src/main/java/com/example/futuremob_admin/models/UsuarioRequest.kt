package com.example.futuremob_admin.models

data class UsuarioRequest(
    val nome: String,
    val cpf: String,
    val rg: String,
    val dataNascimento: String,
    val sexo: String,
    val telefoneCelular: String,
    val admin: Boolean,
    val caminhoImagemPerfil: String,
    val email: String,
    val senha: String
)