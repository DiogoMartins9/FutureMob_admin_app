package com.example.futuremob_admin

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.futuremob_admin.models.UsuarioResponse
import com.example.futuremob_admin.service.UsuarioService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class UsuarioActivity : AppCompatActivity() {

    private lateinit var recyclerUsuarios: RecyclerView
    private lateinit var adapter: UsuarioAdapter
    private lateinit var service: UsuarioService

    private val listaUsuarios = mutableListOf<UsuarioResponse>()
    private val listaFiltrada = mutableListOf<UsuarioResponse>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_usuarios)

        val edtBuscar = findViewById<EditText>(R.id.edtBuscarUsuario)

        recyclerUsuarios = findViewById(R.id.recyclerUsuarios)
        val btnVoltar = findViewById<TextView>(R.id.btnVoltarUsuarios)

        btnVoltar.setOnClickListener {
            finish()
        }

        adapter = UsuarioAdapter(
            mutableListOf(),
            onEditar = { usuario ->
                val intent = Intent(this, UsuarioFormActivity::class.java)
                intent.putExtra("idUsuario", usuario.id)
                startActivity(intent)
            },
            onAtivarDesativar = { usuario ->
                ativarDesativarUsuario(usuario)
            }
        )

        recyclerUsuarios.layoutManager = LinearLayoutManager(this)
        recyclerUsuarios.adapter = adapter

        service = ClientRetrofit.instance.create(UsuarioService::class.java)

        edtBuscar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filtrar(s?.toString() ?: "")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        carregarUsuarios()
    }

    private fun carregarUsuarios() {
        recyclerUsuarios.visibility = View.GONE

        service.listarUsuarios().enqueue(object : Callback<List<UsuarioResponse>> {
            override fun onResponse(
                call: Call<List<UsuarioResponse>>,
                response: Response<List<UsuarioResponse>>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    val lista = response.body()!!

                    listaUsuarios.clear()
                    listaUsuarios.addAll(lista)

                    if (listaUsuarios.isEmpty()) {
                        recyclerUsuarios.visibility = View.GONE
                    } else {
                        adapter.atualizarLista(listaUsuarios)
                        recyclerUsuarios.visibility = View.VISIBLE
                    }
                } else {
                    Toast.makeText(
                        this@UsuarioActivity,
                        "Erro ao carregar usuários",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<List<UsuarioResponse>>, t: Throwable) {
                Toast.makeText(
                    this@UsuarioActivity,
                    "Falha na comunicação com o servidor",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun filtrar(termo: String) {
        listaFiltrada.clear()

        if (termo.isBlank()) {
            listaFiltrada.addAll(listaUsuarios)
        } else {
            val termoLower = termo.lowercase(Locale.getDefault())
            listaFiltrada.addAll(
                listaUsuarios.filter {
                    it.nome.lowercase(Locale.getDefault()).contains(termoLower)
                            || it.email.lowercase(Locale.getDefault()).contains(termoLower)
                }
            )
        }

        adapter.atualizarLista(listaFiltrada)
    }

    private fun ativarDesativarUsuario(usuario: UsuarioResponse) {
        service.ativarDesativar(usuario.id).enqueue(object : Callback<UsuarioResponse> {
            override fun onResponse(
                call: Call<UsuarioResponse>,
                response: Response<UsuarioResponse>
            ) {
                if (response.isSuccessful && response.body() != null) {
                    val atualizado = response.body()!!


                    val index = listaUsuarios.indexOfFirst { it.id == atualizado.id }
                    if (index != -1) {
                        listaUsuarios[index] = atualizado
                    }

                    filtrar("")

                    val msg = if (atualizado.ativo) {
                        "Usuário ativado com sucesso"
                    } else {
                        "Usuário desativado com sucesso"
                    }
                    Toast.makeText(this@UsuarioActivity, msg, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this@UsuarioActivity,
                        "Erro ao atualizar usuário",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<UsuarioResponse>, t: Throwable) {
                Toast.makeText(
                    this@UsuarioActivity,
                    "Falha na comunicação com o servidor",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
